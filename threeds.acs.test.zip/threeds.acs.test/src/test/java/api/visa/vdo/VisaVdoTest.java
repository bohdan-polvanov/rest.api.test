package api.visa.vdo;

import api.BaseApiTest;
import org.json.JSONObject;
import java.util.Collection;
import io.restassured.http.Method;
import org.testng.annotations.Test;
import ua.upc.api.conditions.Condition;
import ua.upc.provider.request.VisaVdoDataProvider;

public class VisaVdoTest extends BaseApiTest{
    @Test(dataProvider = "visa_VDO_BRW_I07_CAVV_RBA_ENABLED", dataProviderClass = VisaVdoDataProvider.class, groups = "rbaFraEnabled")
    public void initOne(JSONObject body, Collection<Condition> condition, String testCaseDescription) {
        assureRequest
                .setDescription(testCaseDescription)
                .setPath(visaPath)
                .setBody(body)
                .sendRequest(Method.POST)
                .shouldHave(condition);
    }

    @Test(dataProvider = "visa_VDO_BRW_I07_CAVV_RBA_DISABLED", dataProviderClass = VisaVdoDataProvider.class)
    public void initTwo(JSONObject body, Collection<Condition> condition, String testCaseDescription) {
        assureRequest
                .setDescription(testCaseDescription)
                .setPath(visaPath)
                .setBody(body)
                .sendRequest(Method.POST)
                .shouldHave(condition);
    }
}