package api;

import org.testng.ITest;
import ua.upc.api.AssureRequest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import static ua.upc.api.AssureRequest.initApiTest;
import static ua.upc.utilities.db.IssuerDatabaseUpdater.disableRbaAndFra;
import static ua.upc.utilities.db.IssuerDatabaseUpdater.enableRbaAndFra;

public class BaseApiTest implements ITest {
    protected String visaPath = "/api/v1/auth/visa";

    protected ThreadLocal<String> testName = new ThreadLocal<>();

    protected AssureRequest assureRequest = initApiTest().disableSslValidation()
            .setUrl("https://acstest4.ad.upc.intranet:8444")
            .addHeader("Content-Type", "application/json");

    @Override
    public String getTestName() {
        return testName.get();
    }

    @BeforeMethod
    public void setupTestName(java.lang.reflect.Method method, Object[] testData) {
        if (testData != null && testData.length > 2) {
            testName.set(String.valueOf(testData[2]));
        } else {
            testName.set(method.getName());
        }
    }

    @BeforeMethod(onlyForGroups = "rbaFraEnabled")
    public void enableRbaFraBeforeTest() {
        enableRbaAndFra();
    }

    @AfterMethod(onlyForGroups = "rbaFraEnabled", alwaysRun = true)
    public void disableRbaFraAfterTest() {
        disableRbaAndFra();
    }
}
