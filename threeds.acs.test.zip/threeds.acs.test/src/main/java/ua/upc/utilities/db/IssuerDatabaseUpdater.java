package ua.upc.utilities.db;

import org.slf4j.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import org.slf4j.LoggerFactory;
import java.sql.PreparedStatement;

public final class IssuerDatabaseUpdater {
    private static final String JDBC_URL = "jdbc:oracle:thin:@//acstdb.upc.intranet:2483/ACST";
    private static final String USERNAME = "ACS_UPC_TEST";
    private static final String PASSWORD = "sdqwe54321asdqwe321asdqwe25~!!";
    private static final String RBA_CHAIN_ID = "b51dbb42-03d1-4fdd-a5c1-a4353e8da466";
    private static final String ISSUER_NAME = "auto_test";
    private static final Logger log = LoggerFactory.getLogger(IssuerDatabaseUpdater.class);

    public static void enableRbaAndFra() {
        String sql = "UPDATE ISSUER SET RBA_CHAIN_ID = ?, FORCE_RISK_ASSESSMENT = 1 where ISSUER_NAME = ?";
        executeUpdate(sql, RBA_CHAIN_ID, ISSUER_NAME);
    }

    public static void disableRbaAndFra() {
        String sql = "UPDATE ISSUER SET RBA_CHAIN_ID = NULL, FORCE_RISK_ASSESSMENT = 0 where ISSUER_NAME = ?";
        executeUpdate(sql, ISSUER_NAME);
    }

    private static void executeUpdate(String sql, Object... parameters) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (int i = 0; i < parameters.length; i++) {
                statement.setObject(i + 1, parameters[i]);
            }

            int updatedRows = statement.executeUpdate();

            log.info("✅ ISSUER table updated successfully. Affected rows: {}", updatedRows);

            if (updatedRows == 0) {
                log.warn("⚠️ No rows were updated in the ISSUER table.");
            }
        } catch (SQLException e) {
            log.error("❌ Failed to update ISSUER table. SQL state: {}, error code: {}", e.getSQLState(), e.getErrorCode(), e);
            throw new RuntimeException("Failed to update ISSUER table", e);
        }
    }
}
