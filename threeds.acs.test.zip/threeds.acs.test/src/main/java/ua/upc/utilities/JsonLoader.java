package ua.upc.utilities;

import java.io.File;
import org.slf4j.Logger;
import org.json.JSONObject;
import java.io.IOException;
import org.slf4j.LoggerFactory;
import org.apache.commons.io.FileUtils;
import java.nio.charset.StandardCharsets;

public final class JsonLoader {
    private static final Logger log = LoggerFactory.getLogger(JsonLoader.class);

    public static JSONObject loadJsonFile(String path) {
        File jsonFile = new File(path);

        log.info("Loading JSON file: {}", jsonFile.getAbsolutePath());

        if (!jsonFile.exists()) {
            log.error("JSON file was not found: {}", jsonFile.getAbsolutePath());
            throw new IllegalArgumentException("JSON file was not found: " + jsonFile.getAbsolutePath());
        }

        try {
            String jsonContent = FileUtils.readFileToString(jsonFile, StandardCharsets.UTF_8);
            JSONObject jsonObject = new JSONObject(jsonContent);
            log.info("✅ JSON file loaded successfully: {}. Fields count: {}", jsonFile.getName(), jsonObject.length());
            return jsonObject;
        } catch (IOException e) {
            log.error("❌ Failed to read JSON file: {}", jsonFile.getAbsolutePath(), e);
            throw new RuntimeException("Failed to read JSON file: " + jsonFile.getAbsolutePath(), e);
        } catch (Exception e) {
            log.error("❌ Invalid JSON format in file: {}", jsonFile.getAbsolutePath(), e);
            throw new IllegalArgumentException("Invalid JSON format in file: " + jsonFile.getAbsolutePath(), e);
        }
    }
}