package ua.upc.api.validation;

public class AResValidation {
}
