package ua.upc.provider.response;

import java.util.List;
import java.util.Collection;
import ua.upc.api.conditions.Condition;

public class AResValidation extends BaseValidation {
    public static Collection<Condition> visa_VDO_BRW_I07_CAVV() {
        return List.of(
                ARES_status_code_200,
                ARES_Content_Type,
                ARES_TRAN_STATUS_I,
                ARES_ECI_07,
                authenticationValue_notNull
        );
    }

    public static Collection<Condition> visa_VDO_BRW_N07_NoCAVV() {
        return List.of(
                ARES_status_code_200,
                ARES_Content_Type,
                ARES_TRAN_STATUS_N,
                ARES_ECI_07,
                ARES_TRAN_STATUS_REASON_09,
                authenticationValue_Null
        );
    }
}
