package ua.upc.provider.request;

import java.util.UUID;
import org.json.JSONObject;
import java.time.ZoneOffset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import static ua.upc.utilities.JsonLoader.loadJsonFile;

public class AReqDataConstructor {
    private JSONObject json;

    public AReqDataConstructor(String path) {
        json = loadJsonFile(path);
        setDsTransID();
        setPurchaseDate();
        setThreeDSServerTransID();
    }

    public JSONObject getJson() {
        return json;
    }

    public static AReqDataConstructor initAReq(String path) {
        return new AReqDataConstructor(path);
    }

    public AReqDataConstructor setThreeRIInd81(){
        json.put("threeRIInd", "81");
        return this;
    }

    public AReqDataConstructor setThreeRIInd11(){
        json.put("threeRIInd", "11");
        return this;
    }

    public AReqDataConstructor setThreeRIInd10(){
        json.put("threeRIInd", "10");
        return this;
    }

    public AReqDataConstructor setThreeRIInd09(){
        json.put("threeRIInd", "09");
        return this;
    }

    public AReqDataConstructor setThreeRIInd08(){
        json.put("threeRIInd", "08");
        return this;
    }

    public AReqDataConstructor setThreeRIInd07(){
        json.put("threeRIInd", "07");
        return this;
    }

    public AReqDataConstructor setThreeRIInd06(){
        json.put("threeRIInd", "06");
        return this;
    }

    public AReqDataConstructor setThreeRIInd05(){
        json.put("threeRIInd", "05");
        return this;
    }

    public AReqDataConstructor setThreeRIInd04(){
        json.put("threeRIInd", "04");
        return this;
    }

    public AReqDataConstructor setThreeRIInd03(){
        json.put("threeRIInd", "03");
        return this;
    }

    public AReqDataConstructor setThreeRIInd02(){
        json.put("threeRIInd", "02");
        return this;
    }

    public AReqDataConstructor setThreeRIInd01(){
        json.put("threeRIInd", "01");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd06(){
        json.put("threeDSRequestorAuthenticationInd", "06");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd05(){
        json.put("threeDSRequestorAuthenticationInd", "05");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd04(){
        json.put("threeDSRequestorAuthenticationInd", "04");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd03(){
        json.put("threeDSRequestorAuthenticationInd", "03");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd02(){
        json.put("threeDSRequestorAuthenticationInd", "02");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorAuthenticationInd01(){
        json.put("threeDSRequestorAuthenticationInd", "01");
        return this;
    }

    public AReqDataConstructor setPurchaseDate() {
        String purchaseDate = LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        json.put("purchaseDate", purchaseDate);
        return this;
    }

    public AReqDataConstructor setPurchaseCurrency(String value){
        json.put("purchaseCurrency", value);
        return this;
    }

    public AReqDataConstructor setPurchaseAmount(String value){
        json.put("purchaseAmount", value);
        return this;
    }

    public AReqDataConstructor setCardExpiryDate(String cardExpiryDate){
        json.put("cardExpiryDate", cardExpiryDate);
        return this;
    }

    public AReqDataConstructor setAcctNumber(String acctNumber){
        json.put("acctNumber", acctNumber);
        return this;
    }

    public AReqDataConstructor setCardholderName(String cardholderName){
        json.put("cardholderName", cardholderName);
        return this;
    }

    public AReqDataConstructor setMessageCategory02(){
        json.put("messageCategory", "02");
        return this;
    }

    public AReqDataConstructor setMessageCategory01(){
        json.put("messageCategory", "01");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd09(){
        json.put("threeDSRequestorChallengeInd", "09");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd08(){
        json.put("threeDSRequestorChallengeInd", "08");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd07(){
        json.put("threeDSRequestorChallengeInd", "07");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd06(){
        json.put("threeDSRequestorChallengeInd", "06");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd05(){
        json.put("threeDSRequestorChallengeInd", "05");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd04(){
        json.put("threeDSRequestorChallengeInd", "04");
        return this;
    }
    public AReqDataConstructor setThreeDSRequestorChallengeInd03(){
        json.put("threeDSRequestorChallengeInd", "03");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd02(){
        json.put("threeDSRequestorChallengeInd", "02");
        return this;
    }

    public AReqDataConstructor setThreeDSRequestorChallengeInd01(){
        json.put("threeDSRequestorChallengeInd", "01");
        return this;
    }

    public void setDsTransID() {
        json.put("dsTransID", UUID.randomUUID().toString());
    }

    public void setThreeDSServerTransID() {
        json.put("threeDSServerTransID", UUID.randomUUID().toString());
    }

    public AReqDataConstructor setMessageVersion2_2_0(){
        json.put("messageVersion", "2.2.0");
        return this;
    }
}
