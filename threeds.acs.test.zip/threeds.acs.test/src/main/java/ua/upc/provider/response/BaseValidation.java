package ua.upc.provider.response;

import ua.upc.enums.*;
import ua.upc.api.conditions.Condition;
import static ua.upc.api.conditions.Conditions.*;

public abstract class BaseValidation {
    //ARes tranStatus validation
    protected static Condition ARES_TRAN_STATUS_Y = field("transStatus", TranStatus.TRAN_STATUS_Y.getValue());
    protected static Condition ARES_TRAN_STATUS_I = field("transStatus", TranStatus.TRAN_STATUS_I.getValue());
    protected static Condition ARES_TRAN_STATUS_N = field("transStatus", TranStatus.TRAN_STATUS_N.getValue());
    protected static Condition ARES_TRAN_STATUS_C = field("transStatus", TranStatus.TRAN_STATUS_C.getValue());

    //ARes eci validation
    protected static Condition ARES_ECI_N2 = field("eci", EciStatus.ECI_N2.getValue());
    protected static Condition ARES_ECI_N0 = field("eci", EciStatus.ECI_N0.getValue());
    protected static Condition ARES_ECI_00 = field("eci", EciStatus.ECI_00.getValue());
    protected static Condition ARES_ECI_01 = field("eci", EciStatus.ECI_01.getValue());
    protected static Condition ARES_ECI_02 = field("eci", EciStatus.ECI_02.getValue());
    protected static Condition ARES_ECI_05 = field("eci", EciStatus.ECI_05.getValue());
    protected static Condition ARES_ECI_06 = field("eci", EciStatus.ECI_06.getValue());
    protected static Condition ARES_ECI_07 = field("eci", EciStatus.ECI_07.getValue());
    protected static Condition ARES_ECI_P0 = field("eci", EciStatus.ECI_P0.getValue());
    protected static Condition ARES_ECI_P2 = field("eci", EciStatus.ECI_P2.getValue());
    protected static Condition ARES_ECI_P3 = field("eci", EciStatus.ECI_P3.getValue());

    // ARes transStatusReason validation
    protected static Condition ARES_TRAN_STATUS_REASON_01 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_01.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_02 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_02.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_03 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_03.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_04 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_04.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_05 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_05.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_06 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_06.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_07 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_07.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_08 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_08.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_09 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_09.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_10 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_10.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_11 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_11.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_12 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_12.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_13 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_13.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_14 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_14.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_15 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_15.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_16 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_16.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_17 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_17.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_18 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_18.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_19 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_19.getValue());
    protected static Condition ARES_TRAN_STATUS_REASON_20 = field("transStatusReason", TranStatusReason.TRAN_STATUS_REASON_20.getValue());

    //ARes General status validation
    protected static Condition ARES_messageType = field("messageType", GeneralStatus.messageType.getValue());
    protected static Condition ARES_acsOperatorID = field("acsOperatorID", GeneralStatus.acsOperatorID.getValue());
    protected static Condition ARES_messageVersion = field("messageVersion", GeneralStatus.messageVersion.getValue());
    protected static Condition ARES_dsReferenceNumber = field("authenticationType_04", GeneralStatus.dsReferenceNumber.getValue());
    protected static Condition ARES_acsReferenceNumber = field("authenticationType_04", GeneralStatus.acsReferenceNumber.getValue());
    protected static Condition ARES_authenticationType_01 = field("authenticationType_01", GeneralStatus.authenticationType_01.getValue());
    protected static Condition ARES_authenticationType_02 = field("authenticationType_02", GeneralStatus.authenticationType_02.getValue());
    protected static Condition ARES_authenticationType_03 = field("authenticationType_03", GeneralStatus.authenticationType_03.getValue());
    protected static Condition ARES_authenticationType_04 = field("authenticationType_04", GeneralStatus.authenticationType_04.getValue());

    //ARes authenticationValue status validation
    protected static Condition authenticationValue_notNull = fieldNotNull("authenticationValue");
    protected static Condition authenticationValue_Null = fieldNull("authenticationValue");

    //ARes message status validation
    protected static Condition ARES_status_code_200 = statusCode(200);
    protected static Condition ARES_Content_Type = header("Content-Type", "application/json");
}
