package ua.upc.provider.request;

import org.testng.annotations.DataProvider;
import static ua.upc.provider.response.AResValidation.*;
import static ua.upc.provider.request.AReqDataConstructor.initAReq;

public class VisaVdoDataProvider extends BaseData {
    @DataProvider(name = "visa_VDO_BRW_I07_CAVV_RBA_ENABLED")
    public static Object[][] provideVdoBrwI07CavvRbaEnabled() {
        return new Object[][]{
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_5")
                                .setAcctNumber(visa_score_5)
                                .getJson(),
                        visa_VDO_BRW_I07_CAVV(),
                        "visa_VDO_BRW_PA_I07_CAVV_SCORE_5"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_45")
                                .setAcctNumber(visa_score_45)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_PA_N07_NoCAVV_SCORE_45"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_65")
                                .setAcctNumber(visa_score_65)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_PA_N07_NoCAVV_SCORE_65"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_95")
                                .setAcctNumber(visa_score_95)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_PA_N07_NoCAVV_SCORE_95"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setMessageCategory02()
                                .setCardholderName("AT_VISA_SCORE_5")
                                .setAcctNumber(visa_score_5)
                                .getJson(),
                        visa_VDO_BRW_I07_CAVV(),
                        "visa_VDO_BRW_NPA_I07_CAVV_SCORE_5"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setMessageCategory02()
                                .setCardholderName("AT_VISA_SCORE_45")
                                .setAcctNumber(visa_score_45)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_NPA_N07_NoCAVV_SCORE_45"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setMessageCategory02()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_65")
                                .setAcctNumber(visa_score_65)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_NPA_N07_NoCAVV_SCORE_65"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setMessageCategory02()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_95")
                                .setAcctNumber(visa_score_95)
                                .getJson(),
                        visa_VDO_BRW_N07_NoCAVV(),
                        "visa_VDO_BRW_NPA_N07_NoCAVV_SCORE_95"
                }
        };
    }


    @DataProvider(name = "visa_VDO_BRW_I07_CAVV_RBA_DISABLED")
    public static Object[][] provideVdoBrwI07CavvRbaDisabled() {
        return new Object[][]{
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_95")
                                .setAcctNumber(visa_score_95)
                                .getJson(),
                        visa_VDO_BRW_I07_CAVV(),
                        "visa_VDO_BRW_PA_I07_CAVV_SCORE_5"
                },
                {
                        initAReq(brwPath)
                                .setThreeDSRequestorChallengeInd06()
                                .setMessageCategory02()
                                .setThreeDSRequestorAuthenticationInd01()
                                .setCardholderName("AT_VISA_SCORE_95")
                                .setAcctNumber(visa_score_95)
                                .getJson(),
                        visa_VDO_BRW_I07_CAVV(),
                        "visa_VDO_BRW_NPA_I07_CAVV_SCORE_5"
                }
        };
    }
}
