package ua.upc.provider.request;

public abstract class BaseData {
    protected static String brwPath = "src/main/resources/json/default/brw.json";

    protected static String visa_score_5 = "4123450400000013";
    protected static String visa_score_45 = "4123450412345670";
    protected static String visa_score_65 = "4123450498765432";
    protected static String visa_score_95 = "4123450411111116";
}
